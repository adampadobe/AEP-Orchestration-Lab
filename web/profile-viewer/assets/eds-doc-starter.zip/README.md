# EDS document starter (lab stub pack)

These files are **minimal placeholders** from the AEP Orchestration Lab so you can
copy something into SharePoint or Google Drive quickly. They are **not** official
Adobe templates and do not include block markup — replace body copy and structure
using Adobe’s document-based Edge Delivery guidance.

## Official Adobe references (source of truth)

- Experience League — *Set up a content repository for Edge Delivery Services* (SharePoint / Google Drive tabs, index · nav · footer patterns):  
  https://experienceleague.adobe.com/en/docs/experience-manager-learn/sites/edge-delivery-services/developing/content-repository
- *Where to author your site* (content source options):  
  https://www.aem.live/docs/authoring-guide

## Suggested filenames in your folder

- `index.docx` — home page role
- `nav.docx` — shared navigation
- `footer.docx` — shared footer

After uploading, use **Sidekick** to Preview and Publish per Adobe docs.

## License

Stub documents and this README are provided by the lab under the same terms as the
parent repository (MIT). Replace with your own or Adobe-guided content for production.
